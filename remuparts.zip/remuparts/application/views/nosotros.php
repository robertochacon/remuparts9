<?php $this->load->view('layout/header_out') ?>

<center>
	<br><br><br>
	<h1 class="text-white sombra-texto" style="font-family:;">Descubre mas sobre nosotros!</h1>
</center>

<div class="container  animated fadeIn">
<div class="row" style="margin-top:50px;margin-bottom:50px;">
	<div class="col-sm-12 col-md-4 col-lg-4 aling-center">
		<div class="container img_sesion_2">
			<img src="<?php echo base_url('assets/img/home/vision.jpg');?>" class="sombra " width="100%">
		</div>
	</div>
	<div class="col-sm-12 col-md-4 col-lg-4 aling-center">
		<div class="container img_sesion_2">
			<img src="<?php echo base_url('assets/img/home/mision.jpg');?>" class="sombra " width="100%">
		</div>
	</div>
	<div class="col-sm-12 col-md-4 col-lg-4 aling-center">
		<div class="container img_sesion_2">
			<img src="<?php echo base_url('assets/img/home/valores.jpg');?>" class="sombra " width="100%">
		</div>
	</div>
</div>
</div>

</body>
</html>