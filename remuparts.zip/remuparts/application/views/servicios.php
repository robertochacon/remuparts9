<?php $this->load->view('layout/header_out') ?>


<center>
	<br><br><br>
	<h1 class="text-white sombra-texto" style="font-family:;">Nuestros servicios!</h1>
</center>

<div class="container  animated fadeIn">

<div class="row" style="margin-top:50px;margin-bottom:50px;">

	<div class="col-sm-12 col-md-4 col-lg-4 text-center">
		<div class="container">
			<h3 class="text-white">Mantenimiento Preventivo</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
		</div>
	</div>

	<div class="col-sm-12 col-md-4 col-lg-4 text-center">
		<div class="container">
			<h3 class="text-white">Cambio de Banda de Freno</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
		</div>
	</div>

	<div class="col-sm-12 col-md-4 col-lg-4 text-center">
		<div class="container">
			<h3 class="text-white">Cambio de Aceites</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
		</div>
	</div>

<div class="row" style="margin-top:50px;margin-bottom:50px;">

	<div class="col-sm-12 col-md-4 col-lg-4 text-center">
		<div class="container">
			<h3 class="text-white">Reparacion del Motor</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
		</div>
	</div>

	<div class="col-sm-12 col-md-4 col-lg-4 text-center">
		<div class="container">
			<h3 class="text-white">Reparacion del Tren Delantero</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
		</div>
	</div>

	<div class="col-sm-12 col-md-4 col-lg-4 text-center">
		<div class="container">
			<h3 class="text-white">Otros Servicios</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex.</p>
		</div>
	</div>


</div>
</div>


</body>
</html>